
install.packages("monomvn")
library(monomvn)
install.packages("glmnet")
library(glmnet)
install.packages("brms")
library(brms)

#read the data
dataSet <- data('freeny')
y <- as.array(freeny.y)
x <- as.array(freeny.x)
linReg <- lm(y~x)
COEF <- coef(linReg)
sigmasq_orig <- anova(linReg)$"Mean Sq"[2]


#generate draws from the candidate densities
samples <- function(n){
  draws <- array(0,dim=c(6,n))
  draws[c(1:5),] <- rt(n,df=5)
  draws[6,] <- rchisq(n,df=1)
  
  return(draws) 
} 


#calculate the summed errors squared (for the log-likelihood)
getDifferences <- function (n,nobs,draws){
  difference1 <- array(0,dim=c(nobs,n,5))
  difference2 <- array(0,dim=c(n,5))
  for (j in 1:n){
    for (k in 1:nobs){
      
      difference1[k,j,] <- y[k] - draws[1,j] - draws[2,j]*x[k,1] - draws[3,j]*x[k,2] - draws[4,j]*x[k,3] - draws[5,j]*x[k,4]
      
    }}
  
  difference2 <- colSums(difference1)
  difference2 <- difference2 * difference2
  return (difference2)
} 


#calculate the log-likelihoods 
loglike <- function(difference2,draws){
  i <- nrow(difference2)
  j <- ncol(difference2)
  loglike <- array(0,dim=c(i,j))
  loglike<- -(j/2)*log(2*pi) - j*log(sqrt(draws[6,i]))-1/(2*draws[6,i])*difference2
  return(loglike)
}

#calculate the values of the second prior function
lasso_prior1 <- function(draws){
  i <- nrow(draws)
  j <- ncol(draws)
  product <- array(1,dim=c(j,i))
  product <- product/draws[6,]
  
  return (product)
}

#calculate the values of the second prior function
lasso_prior2 <- function(lambda,draws){
  i <- nrow(draws)
  j <- ncol(draws)
  product <- array(1,dim=c(j,i))
  for (k in 1:j){
    for (l in 1:i){
      product[k,l] <- product[k,l]*(lambda/(2*sqrt(draws[6,k])))*exp(-lambda*abs(draws[l,k])/sqrt(draws[6,k]))
    }
  }
  product <- product/draws[6,k]
  return (product)
}


#calculate the weights of betas
calcWeights<-function(n,draws,logtable,priortable){
  weight <- array(0,dim=c(n,5))
  
  for (i in 1:5){
    weight[,i] <- log(abs((logtable[,i]*priortable[,i]))) - log(dt(draws[i,],df=5))
  }
  
  return(weight)
}

#Calculate the estimates of 5 betas
calcBetaEstimate <- function(n,draws,weighttable){
  probabilities <- array(0,dim=c(5,n))
  
  for (i in 1:5){
    probabilities[i,] <- dt(draws[i,],df=5)
  }
  
  
  betaEstimate <- array(0,dim=c(1,5))
  for (i in 1:5){
    betaEstimate[,i]=(draws[i,]%*%weighttable[,i])/(probabilities[i,]%*%weighttable[,i])
  }
  
  return (betaEstimate)
}

#Method to calculate the resultant parameters' mean
calcMean <- function(draws,n,weighttable){
  meanArray <- array(0,c(5,1))
  for (i in 1:5){
    meanArray[i,1]<-(draws[i,]%*%weighttable[,i])/n
  }
  return (meanArray)
}

#Method to calculate the resultant parameters' variance
calcVar <- function(draws,n,weighttable,meanTable){
  thetaSq <-array(0,c(5,1))
  drawsSq <-array(0,c(6,n))
  drawsSq <-draws*draws
  var <-array(0,c(5,1))
  
  for (i in 1:5){
    thetaSq[i,1]<-(drawsSq[i,]%*%weighttable[,i])/n
  }
  
  var<-thetaSq - (meanTable^2)
  
  return (var)
}

#Method to create relevant vectors for plotting in graphs
n_draws <- seq(10,1000,length=50)
betaArray <- array(0,dim=c(50,5,2))
meanArray <- array(0,dim=c(50,5,2))
varianceArray <- array(0,dim=c(50,5,2))

betaPlot1 <- array(0,dim=c(1,5))
betaPlot2 <- array(0,dim=c(1,5))

for (i in 1:50){
  sampleTable <-samples(n_draws[i])
  differenceTable <- getDifferences(n_draws[i],39,sampleTable)
  logliketable<-loglike(differenceTable,sampleTable)
  prior1table <- lasso_prior1(sampleTable)
  weight1table<-calcWeights(n_draws[i],sampleTable,logliketable,prior1table)
  betaPlot1 <- calcBetaEstimate(n_draws[i],sampleTable,weight1table)
  meanArray1 <- calcMean(sampleTable,n_draws[i],weight1table)
  varArray1 <- calcVar(sampleTable,n_draws[i],weight1table,meanArray1)
  betaArray[i,,1]= betaPlot1 
  meanArray[i,,1]=meanArray1
  varianceArray[i,,1]=varArray1
  
  prior2table <- lasso_prior2(0.005,sampleTable)
  weight2table<-calcWeights(n_draws[i],sampleTable,logliketable,prior2table)
  betaPlot2 <- calcBetaEstimate(n_draws[i],sampleTable,weight2table)
  meanArray2 <- calcMean(sampleTable,n_draws[i],weight2table)
  varArray2 <- calcVar(sampleTable,n_draws[i],weight1table,meanArray2)
  betaArray[i,,2]= betaPlot2 
  meanArray[i,,2] = meanArray2
  varianceArray[i,,2]=varArray2
}







#running the importance sampling
sampleTable <-samples(100)
print(sampleTable)
differenceTable <- getDifferences(100,39,sampleTable)
print(differenceTable)
logliketable<-loglike(differenceTable,sampleTable)
print(logliketable)
prior1table <- lasso_prior1(sampleTable)
prior2table <- lasso_prior2(0.005,sampleTable)
print(prior2table)
betaEstimates1 <- calcBetaEstimate(100,sampleTable,logliketable,prior1table)
betaEstimates2 <- calcBetaEstimate(100,sampleTable,logliketable,prior2table)
print(betaEstimates1)
print(betaEstimates2)
print(COEF)
regrmean1 <- calcMean(betaEstimates1,39)
regrmean2 <- calcMean(betaEstimates2,39)
print (regrmean1)
print (regrmean2)
regrvar1 <- calcVar(betaEstimates1,39,regrmean1)
regrvar2 <- calcVar(betaEstimates2,39,regrmean2)
print (regrvar1)
print (regrvar2)

#Method to plot the relevant graphs

plot(n_draws,betaArray[,1,1],xlab='n',ylab='beta1',type='l',col=1)
lines(n_draws,betaArray[,1,2], type='l', col=2)
abline(h=-10.473,col=3,lty=2)
legend('bottomright',c('prior1','prior2','true value'),lty=c(1,1,2),col=1:3)

plot(n_draws,betaArray[,2,1],xlab='n',ylab='beta2',type='l',col=1)
lines(n_draws,betaArray[,2,2], type='l', col=2)
abline(h=0.124,col=3,lty=2)
legend('bottomright',c('prior1','prior2','true value'),lty=c(1,1,2),col=1:3)

plot(n_draws,betaArray[,3,1],xlab='n',ylab='beta3',type='l',col=1)
lines(n_draws,betaArray[,3,2], type='l', col=2)
abline(h=-0.754,col=3,lty=2)
legend('bottomright',c('prior1','prior2','true value'),lty=c(1,1,2),col=1:3)

plot(n_draws,betaArray[,4,1],xlab='n',ylab='beta4',type='l',col=1)
lines(n_draws,betaArray[,4,2], type='l', col=2)
abline(h=0.767,col=3,lty=2)
legend('topright',c('prior1','prior2','true value'),lty=c(1,1,2),col=1:3)

plot(n_draws,betaArray[,5,1],xlab='n',ylab='beta5',type='l',col=1)
lines(n_draws,betaArray[,5,2], type='l', col=2)
abline(h=1.331,col=3,lty=2)
legend('bottomleft',c('prior1','prior2','true value'),lty=c(1,1,2),col=1:3)



