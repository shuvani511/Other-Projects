%Stochastic Calculus Assignment 2 by Shuvani Choudhury(12768553)
clear;clc;

%Parameters
rng(3);
numsim=1000;
N=1000;
T=10;
R=0.03;
S0=100;
sigma=0.3;
delta=0.02;
r=log(1+R);

%Monte Carlo Simulation
[C0,payoffs2,s,C,Cl,Cu]=callmc(S0,R,T,sigma,delta,N,numsim);
X=[C,Cl,Cu];
disp(X);

%Refined Simulation (using Control Variate)
d1=((-delta+(.5*sigma^2))*T)/(sigma*sqrt(T));
d2=d1-(sigma*sqrt(T));
G0_a=S0*(1+(exp(-delta*T)*normcdf(d1))-normcdf(d2));
G0=exp(-r*T)*payoffs2;
Cntrl_var=G0-G0_a;
X=[ones(length(Cntrl_var),1), Cntrl_var];
b=X\C0;
disp(b);
X=Cntrl_var;
disp(fitlm(X,C0));





