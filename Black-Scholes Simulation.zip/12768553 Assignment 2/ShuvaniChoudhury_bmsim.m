function [X]=bmsim(T,N,X0,mu,sigma)
%function W=bmsim(T,N)
deltaT = T/N;
X=zeros(N+1,1);
X(1)=X0;
z=randn(N,1);
for j=1:N
    X(j+1)=X(j)+mu*deltaT+sigma*sqrt(deltaT)*z(j);
end
end