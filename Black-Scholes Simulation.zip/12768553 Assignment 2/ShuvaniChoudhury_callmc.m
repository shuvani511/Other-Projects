function [g,payoffs2,s,C,Cl,Cu] = callmc(S0,R,T,sigma,delta,N,numsim)
%[C,Cl,Cu]=callmc(S0,R,T,sigma,N,numsim)
r=log(1+R);
X0=log(S0);nu=r-delta-.5*sigma^2;

%Parameters
tvec=(N/T):(N/T):N;
Rt = zeros(T,1);
payoffs1=zeros(numsim,1);
payoffs2=zeros(numsim,1);

%Simulation
for j=1:numsim
    Spath=exp(bmsim(T,N,X0,nu,sigma));
    i=1;
    for k=tvec
        Rt(i)=(Spath(k+1)-Spath(k-(N/T)+1))/Spath(k-(N/T)+1);
        i=i+1;
    end
    intermd=1+max(Rt,R);
    %For question 3
    payoffs1(j)=Spath(1)*prod(intermd);
    %For question 4
    payoffs2(j)=max(Spath(1)*((1+R)^T),Spath(N+1));
end
g=exp(-r*T)*payoffs1;
C=mean(g);s=std(g);
Cl=C-1.96/sqrt(numsim)*s;
Cu=C+1.96/sqrt(numsim)*s;