library(psychometric)
library(MASS)
rm(list=ls())
winedat <- read.csv("C:\\Users\\LENOVO\\Desktop\\data-table-B11.csv", header = T, sep =",")
attach(winedat)

newdat <- winedat[order(Flavor)]
Flavor <- newdat$Flavor
Quality <- newdat$Quality

fitted.model1 <- lm(Quality~Flavor,data=winedat)
plot(Flavor,Quality,pch=15, col="blue",xlim=c(2.5,7.5),ylim=c(7.5,16,5))
abline(fitted.model1,lty=1,lwd=2,col="blue")

R.student.resid <- studres(fitted.model1)
yhat <- fitted(fitted.model1)
plot(yhat,R.student.resid,pch=15,col="blue")
abline(h=0,lty=1,lwd=1,col="blue")

fitted.model3 <- lm(Quality~Flavor+I(Flavor^2)+I(Flavor^3))
COEFF <- coef(fitted.model3)
yhat <- fitted(fitted.model3)
plot(Flavor,Quality,pch=15, col="blue",xlim=c(2.5,7.5),ylim=c(7.5,16,5))
par(new = TRUE)
plot(Flavor,yhat,axes = FALSE, col="blue",type="l",lwd=2,xlim=c(2.5,7.5),ylim=c(7.5,16,5),xlab="",ylab="")

R.student.resid <- studres(fitted.model3)
yhat <- fitted(fitted.model3)
plot(yhat,R.student.resid,pch=15,col="blue")
abline(h=0,lty=1,col="blue")

y <- Quality
x <- Flavor
lenx <- length(x)
xmt <- rep(0,lenx)
xmt0 <- rep(0,lenx)
for (i in 1:lenx){
  if (x[i] > 5){
    xmt[i] <- x[i]-5
    xmt0 <- 1
  }
}
fitted.model3n <- lm(y~x+I(x^2)+I(x^3)+xmt0+xmt+I(xmt^2)+I(xmt^3))
yhat <- fitted(fitted.model3n)
plot(x,y,col="blue",xlim=c(2.5,7.5),ylim=c(7.5,16,5))
par(new=TRUE)
plot(x,yhat,axes = FALSE, col="blue",type="l",lwd=2,xlim=c(2.5,7.5),ylim=c(7.5,16,5),xlab="",ylab="")
