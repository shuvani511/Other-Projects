library(MASS)
dat <- read.csv("C:\\Users\\LENOVO\\Desktop\\data-prob-5-2.csv", header = T, sep=",")

y <- dat[,2]
x <- dat[,1]
fitted_model <- lm(y~x)

plot(x,y,pch=15,col="blue")
abline(fitted_model)

anova(fitted_model)

y <- log(y)
x <- 1/x
fitted_model2 <- lm(y~x)
anova(fitted_model2)

plot(x,y,pch=15,col="blue")
abline(fitted_model2)
