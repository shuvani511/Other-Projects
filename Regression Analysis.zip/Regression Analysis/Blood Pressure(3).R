library (MASS)
dat <- read.csv("C:\\Users\\LENOVO\\Desktop\\weight_systolic.csv")
y <- dat[,2]
x <- dat[,1]
fitted_model <- lm(y~x)

anova(fitted_model)

summary(fitted_model)

plot(x,y,pch=15,col="blue")

beta0 <- coef(fitted_model)[1]
beta1 <- coef(fitted_model)[2]
abline(beta0,beta1)
resid <- residuals(fitted_model)

plot(x,resid,pch=15,col="red")
lines(c(min(x),max(x)),c(0,0))
