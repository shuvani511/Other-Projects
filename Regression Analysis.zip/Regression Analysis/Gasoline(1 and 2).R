#mileage.R
#
library(MASS)
dat <- read.csv("C:\\Users\\LENOVO\\Desktop\\data-table-B3.csv", header = T, sep=",")
dat
y <- dat[,1]
x <- dat[,2]

plot(x,y,pch=16)

x <- 0.425*x
y <- 16.387*y

fitted_model <- lm(y~x)
COEF <- coef(fitted_model)
beta0 <- COEF[1]
beta1 <- COEF[2]
abline(beta0,beta1)

mx <- mean(x)
my <- mean(y)
Sxx <- sum((x-mx)^2)
Sxy <- sum(y*(x-mx))
beta1 <- Sxy/Sxx
beta0 <- my - beta1*mx

yhat <- predict(fitted_model)
residual <- y-yhat
f1 <- sum(residual)
f2 <- sum(residual^2)

plot(x,residual)
lines(c(min(x),max(x)), c(0,0))

newdata <- data.frame(x=1998)
predict(fitted_model,newdata)

sum(x*residual)
sum(yhat*residual)

plot(x,y)
abline(fitted_model)
for (i in 1:length(x)) lines(c(x[i],x[i]),c(y[i],yhat[i]))

SST <- sum(y^2) - (sum(y))^2/length(y)
SSxy <- sum(y*x) -sum(y)*sum(x)/length(y)
SSRes <- SST - beta1*SSxy
sigma2hat <- SSRes/(length(y)-2)

beta1 <- summary(fitted_model)$coeff[2,1]
se.beta1 <- summary(fitted_model)$coeff[2,2]
n <- length(y)
prob <- 0.99 + (1-0.99)/2
lowerbound <- beta1 - qt(prob,df=n-2)*se.beta1
upperbound <- beta1 + qt(prob,df=n-2)*se.beta1

beta0 <- summary(fitted_model)$coeff[1,1]
se.beta0 <- summary(fitted_model)$coeff[1,2]
n <- length(y)
prob <- 0.99 + (1-0.99)/2
lowerbound2 <- beta0 - qt(prob,df=n-2)*se.beta0
upperbound2 <- beta0 + qt(prob,df=n-2)*se.beta0

MSRes <- anova(fitted_model)$"Mean Sq"[2]
prob <- 0.99 + (1-0.99)/2
n <- length(x)
lowerbound3 <- (n-2)*MSRes/qchisq(1-prob, df=n-2)
upperbound3 <- (n-2)*MSRes/qchisq(prob, df=n-2)

x0 <- 2000
n <- length(x)
Sxx <- sum ((x-mx)^2)
mean.y <- beta0 + beta1*x0
lowerbound4 <- mean.y - qt(prob,df=n-2)*sqrt(MSRes*(1/n + (x0-mean(x))^2/Sxx))
upperbound4 <- mean.y + qt(prob,df=n-2)*sqrt(MSRes*(1/n + (x0-mean(x))^2/Sxx))

rsquare <- summary(fitted_model)$r.squared

corr <- cor(x,y)
corrsq <- cor(x,y)^2

install.packages("psychometric")
library(psychometric)
t0 <- corr*sqrt(length(x)-2)/sqrt(1-corr^2)
CIr(corr,n=length(x),level=0.99)
