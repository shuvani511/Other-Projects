options(repos = c(CRAN = "http://cran.rstudio.com"))
install.packages("psychometric")
library(psychometric)
library(MASS)

dat <- read.csv("C:\\Users\\LENOVO\\Desktop\\data-table-B11.csv", header = T, sep =",")
attach(dat)
cor(dat)
pairs(dat, pch=16, col="blue")
fitted_model <- lm(Quality~Flavor)
plot(Flavor,Quality,pch=16, col="blue")
abline(fitted_model)
resid <- resid(fitted_model)
plot(Flavor,resid_QF,pch=16,col="blue")
lines(c(min(Flavor),max(Flavor)),c(0,0))
summary(fitted_model)

scatterplot3d(Flavor,Oakiness,Quality, main="3D Scatterplot", pch=15, color="red", angle=45)
scatterplot3d(Flavor,Oakiness,Quality, main="3D Scatterplot", pch=15, color="red", angle=45)
data3 <- data.frame(Quality,Flavor,Oakiness)
pairs(data3)

mod1 <- lm(Quality~Flavor)
anova(mod1)

mod2 <- lm(Quality~Flavor + Oakiness)
anova(mod2)

mod3 <- lm(Quality~Oakiness + Flavor)
anova(mod3)

mod0 <- lm(Quality~1)
anova(mod0)

anova(mod0,mod3)

nobs <- length(Quality)
one <- rep(1,nobs)
x <- array(c(one,Flavor<Oakiness),dim=c(nobs,3))

y <- as.array(Quality)

xPy <- t(x) %*% y

xPx <- t(x) %*% x

xPxI <- solve(xPx)

Betahat <- solve(xPx,xPy)

H <- x %*% xPxI %*% t(x)
dim(H)
HD <- diag(H)
max(HD)
min(HD)

y <- dat[,6]
x1 <- dat[,4]
x2 <- dat[,2]
x3 <- dat[,3]
x4 <- dat[,5]
x5 <- dat[,1]

anova(lm(y~1),lm(y~x1+x2))

x345 <- x3 + x4 + x5
anova(lm(y~x1+x2+x345), lm(y~x1+x2+x3+x4+x5))

nobs <- length(y)
one <- rep(1,nobs)
X <- array(c(one,x1,x2,x3,x4,x5),dim=c(nobs,6))
xPxI
sigma2 <- anova(lm(y~x1+x2+x3+x4+x5))$"Mean Sq"[6]
VarCov <- sigma2*xPxI
diagVarcov <- diag(VarCov)
sqrt(diagVarcov)

summary(lm(y~x1+x2+x3+x4+x5))

install.packages("leaps")
install.packages("olsrr")
install.packages("scatterplot3d")
library(leaps)
library(olsrr)
library(scatterplot3d)

winedat <- data.frame(y,x1,x2,x3,x4,x5)
fitted_model <- lm (y~x1+x2+x3+x4+x5, data = winedat)
allout <- ols_step_all_possible(fitted_model)
plot(allout)
allout

fitted_model2 <- lm(y~x1+x2+x4)
summary(fitted_model2)
fitted <- predict(fitted_model2)
e <- resid(fitted_model2)
obsn <- seq(1:length(y))
plot(obsn,e,pch=15,col="red")
abline(h=0,col="blue",lty=3)

qqnorm(e,pch=15,col="red",
       ylab="Raw Residuals",
       xlab="Normal Percentiles",
       main="Normal Q-Q Probability Plot")
qqline(e)

shapiro.test(e)

yhat <- fitted(fitted_model2)
plot(yhat,e,pch=15,col="red")
abline(h=0,col="blue",lty=3)
plot(x1,e,pch=15,col="red")
abline(h=0,col="blue",lty=3)
plot(x2,e,pch=15,col="red")
abline(h=0,col="blue",lty=3)
plot(x4,e,pch=15,col="red")
abline(h=0,col="blue",lty=3)

lastv <-length(anova(fitted_model2)$"Mean Sq")
MSRes <- anova(fitted_model2)$"Mean Sq"[lastv]
std.resid <- e/sqrt(MSRes)
plot(yhat,std.resid,pch=15,col="red")
abline(h=0,col="blue",lty=3)
plot(x1,std.resid,pch=15,col="red")
abline(h=0,col="blue",lty=3)
plot(x2,std.resid,pch=15,col="red")
abline(h=0,col="blue",lty=3)
plot(x4,std.resid,pch=15,col="red")
abline(h=0,col="blue",lty=3)

one <-rep(1,length(y))
X <- array(c(one,x1,x2,x4),dim=c(length(y),4))
xPxI
H <- X %*% xPxI %*% t(X)
Hii <- diag(H)


lastv <-length(anova(fitted_model2)$"Mean Sq")
MSRes <- anova(fitted_model2)$"Mean Sq"[lastv]
stu.resid <- e/sqrt(MSRes*(1-Hii))

lastv <-length(anova(fitted_model2)$"Mean Sq")
MSRes <- anova(fitted_model2)$"Mean Sq"[lastv]
PRESS.resid <- e/(1-Hii)

lastv <-length(anova(fitted_model2)$"Mean Sq")
MSRes <- anova(fitted_model2)$"Mean Sq"[lastv]
s2 <- ((length(y)-4)*MSRes - e^2/(1-Hii))/(length(y)-5)
stu.resid <- e/sqrt(S2*(1-Hii)
                    
attach(dat)
plot(Flavor,Quality,pch=15,col="red")
abline(lm(Quality~Flavor),lwd=2)
geom.mean <- exp(sum(log(Quality))/length(Quality))
prod(Quality)^(1/length(Quality))
MSRes <- as.numeric()
lambda <- seq(0.1,3.0,0.05)
for (i in 1:length(lambda)){
  y.lambda <- (Quality^lambda[i]-1)/(lambda[i]*geom.mean^(lambda[i]-1))
MSRes[i] <- anova(lm(y.lambda~Flavor))$"Mean Sq"[2]
}
plot(lambda,MSRes,pch=16,col="red")
index <- MSRes == min(MSRes)
print(data.frame(lambda,MSRes))

fitted.model <- lm(y~x1+x2+x4)
print(influence.measures(fitted.model))
cd <- cooks.distance(fitted.model)
obs <- seq(1:length(cd))
plot(obs,cd,pch=15,col="red",ylim=c(0.0,1.0))
p <- 4
nmp <- length(y)-p
abline(h=qf(0.5, df1=p, df2=nmp))

R.student.resid <- studres(fitted.model)
yhat <- fitted(fitted.model)
plot(yhat,R.student.resid,pch=15,col="red")
abline(h=0,col="black")