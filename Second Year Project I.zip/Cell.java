import java.util.*;
public class Cell{
  
  private final int rowNumber;
  private final int columnNumber;
  private int blockNumber;
  private int value;
  private ArrayList<Integer> possibleValues = new ArrayList<Integer>();
  private boolean solved = false;
  
   // constructor for a object of type Cell with the given initial values
  public Cell(int newRowNumber, int newColumnNumber, int newBlockNumber, int newValue, ArrayList<Integer> newPossibleValues){
    this.rowNumber = newRowNumber;
    this.columnNumber = newColumnNumber;
    this.blockNumber = newBlockNumber;
    this.value = newValue;
    this.possibleValues = newPossibleValues;
  }
  
  // returns the row number of this cell
  public int getRowNumber(){
    return this.rowNumber;
  }
  
  // returns the column number of this cell
  public int getColumnNumber(){
    return this.columnNumber;
  }
  
  // returns the column number of this cell
  public void setBlockNumber(int x){
    this.blockNumber=x;
  }
  
  // returns the column number of this cell
  public int getBlockNumber(){
    return this.blockNumber;
  }
  
  // adds the given value to the list of possible values of this cell
  public void addPossibleValue(int x){
    this.possibleValues.add(x);
  }
  
  // removes the given value to the list of possible values of this cell
  public void removePossibleValue(int x){
    if (this.possibleValues.contains(x)){
    int index = this.possibleValues.indexOf(x);
    this.possibleValues.remove(index);
    }
  }
  
  //returns the list of possible values of the cell
  public int getPossibleValue(int x){
    return this.possibleValues.get(x);
  }
    
     //returns the list of possible values of the cell
  public boolean containsValue(int x){
    return this.possibleValues.contains(x);
  }
    //returns the list of possible values of the cell
  public int numberOfCandidates(){
    return this.possibleValues.size();
  }
  
  // returns the value of this cell
  public int getValue(){
    return this.value;
  }
  
  // sets the value of this cell
  public void setValue(int x){
    this.value=x;}
  
  
  //returns the state of this cell
 public boolean stateOfCell(){
   if (this.possibleValues.size()==1){
     this.solved=true;
   }
    return this.solved;
 }
  
}


  