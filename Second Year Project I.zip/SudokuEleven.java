//Shuvani Choudhury (i6108206)
//Maartje van Kessel (i6143670)
import java.util.*;
import java.io.*;

public class SudokuEleven{
  public static void main(String args[]){
    
    String filename = args[0];
    //Initializing the queue
    Queue <Integer> hints = null;
    try{
      //Using the method to read the text file as an array
      hints = hintQueue(filename);
    }
    catch (FileNotFoundException e){
      e.printStackTrace();
    }
    
    //Applying the methods to solve the sudoku
    Cell sudoku [][] = new Cell [9][9];
    Cell copy[][]= new Cell[9][9];
  
    sudoku=sudoku();
    
    sudoku=initializeHints(sudoku,hints);
    sudoku=Enumeration(sudoku,hints,copy);
    
    
    //Printing the final sudoku
    for (int i=0; i<9 ; i++){
      for (int j=0; j<9 ; j++){
        System.out.print(sudoku[i][j].getValue() + " ");
      }
      System.out.println();
    }
    //A method to print out our final result (in contrast to the arrays describing steps in-between)
    boolean checkSolved = Solved(sudoku);
    if(checkSolved){
      for (int i=0; i<9 ; i++){
        for (int j=0; j<9 ; j++){
          System.out.print(sudoku[i][j].stateOfCell()+ " " + sudoku[i][j].numberOfCandidates()+ " ");
        }
        System.out.println();
      }
    }}
  
  //A method to read the rows of the text as inidividual hints
  public static Queue <Integer> hintQueue(String filename)
    
    throws java.io.FileNotFoundException{
    
    File file = new File(filename);
    Scanner input = new Scanner (file);
    
    int numberOfHints = input.nextInt();
    
    Queue<Integer> hints = new Queue<Integer>();
    
    for (int i=0;i<(numberOfHints*3);i++){
      
      hints.enqueue(input.nextInt());
    }
    input.close();
    
    return hints;
  }
  
  public static Cell[][] sudoku(){
    
    //Initialize the matrix i.e. give row numbers, column number, block numbers, and each cells a list of possible values. By default, we set the initial value at 0.
    Cell sudoku [][] = new Cell [9][9];
    
    //3x3 for loops to be able to give the appropiate blocknumber to a cell
    for (int i=0;i<3;i++){
      for (int j=0; j<9;j++){
        int rowNumber = i;
        int columnNumber = j;
        int value = 0;
        int blockNumber = 0;
        if (j<3){
          blockNumber = 1;}
        else if(j>2 && j<6){
          blockNumber = 2;}
        else{
          blockNumber =3;}
        ArrayList <Integer> possibleValues = new ArrayList<Integer>();
        for(int k=1; k<=9;k++){
          possibleValues.add(k);
        }
        
        Cell newCell = new Cell (rowNumber, columnNumber, blockNumber, value, possibleValues);
        sudoku [i][j] = newCell;
      }
    }
    
    for (int i=3;i<6;i++){
      for (int j=0; j<9;j++){
        int rowNumber = i;
        int columnNumber = j;
        int value = 0;
        int blockNumber =0;
        if (j<3){
          blockNumber = 4;}
        else if(j>2 && j<6){
          blockNumber = 5;}
        else{
          blockNumber =6;}
        ArrayList <Integer> possibleValues = new ArrayList<Integer>();
        for (int k=1;k<=9;k++){
          possibleValues.add(k);
        }
        
        Cell newCell = new Cell (rowNumber, columnNumber, blockNumber, value, possibleValues);
        sudoku [i][j] = newCell;
      }
    }
    
    for (int i=6;i<9;i++){
      for (int j=0; j<9;j++){
        int rowNumber = i;
        int columnNumber = j;
        int value = 0;
        int blockNumber =0;
        if (j<3){
          blockNumber = 7;}
        else if(j>2 && j<6){
          blockNumber = 8;}
        else{
          blockNumber =9;}
        ArrayList <Integer> possibleValues = new ArrayList<Integer>();
        for (int k=1;k<=9;k++){
          possibleValues.add(k);
        }
        
        Cell newCell = new Cell (rowNumber, columnNumber, blockNumber, value, possibleValues);
        sudoku [i][j] = newCell;
      }
    }
    return sudoku;
  }
  
  
  //Apply hints to the initial matrix
  public static Cell [][] initializeHints (Cell [][] sudoku, Queue<Integer> hints){
    while(hints.isEmpty()!=true){
      int hintRow = hints.dequeue();
      int hintColumn = hints.dequeue();
      int hintValue = hints.dequeue();
      Cell solved = sudoku[hintRow][hintColumn];
      
      sudoku[hintRow][hintColumn].setValue(hintValue);
      
      for (int j=1;j<=9;j++){
        if (j!=hintValue){
          sudoku[hintRow][hintColumn].removePossibleValue(j);
        }
      }
      
      for (int j=0; j<9; j++){
        if (j!= solved.getRowNumber()){
          if (sudoku[j][solved.getColumnNumber()].getValue()==0){
            sudoku[j][solved.getColumnNumber()].removePossibleValue(solved.getValue());
          }
        }
      }
      
      for (int j=0; j<9; j++){
        if (j!=solved.getColumnNumber()){
          if (sudoku[solved.getRowNumber()][j].getValue()==0){
            sudoku[solved.getRowNumber()][j].removePossibleValue(solved.getValue());
          }
        }
      }
      for (int i=0; i<9; i++){
        for (int j=0; j<9; j++){
          if (sudoku[i][j].getValue()==0){
            if (sudoku[i][j].getBlockNumber()==solved.getBlockNumber()){
              sudoku[i][j].removePossibleValue(solved.getValue());
            }
          }
        }
      }
    }
    return sudoku;
  }
  
  
  // This method applies the Logic Rules basics. Input is the sudoku and row & column number of a solved cell.
  public static Cell[][] LogicRules (Cell[][] sudoku, Queue<Integer>hints){
    while(!hints.isEmpty()){
      int x = hints.dequeue();
      int y = hints.dequeue();
      Cell solved = sudoku[x][y];
      
      
      
      for (int j=0; j<9; j++){
        if (j!=x){
          if (sudoku[j][y].getValue()==0){
            sudoku[j][y].removePossibleValue(solved.getValue());
          }
        }
      }
      
      for (int j=0; j<9; j++){
        if (j!=y){
          if (sudoku[x][j].getValue()==0){
            sudoku[x][j].removePossibleValue(solved.getValue());
          }
        }
      }
      for (int i=0; i<9; i++){
        for (int j=0; j<9; j++){
          if (sudoku[i][j].getBlockNumber()==solved.getBlockNumber()){
            if (sudoku[i][j].getValue()==0){
              sudoku[i][j].removePossibleValue(solved.getValue());
            }
          }
        }
      }
    }
    
    
    //Searching for new hints
    for( int i=0;i<9;i++){
      for(int j=0;j<9;j++){
        if((sudoku[i][j].numberOfCandidates()==1)&&(sudoku[i][j].getValue()==0)){
          
          sudoku[i][j].setValue(sudoku[i][j].getPossibleValue(0));
          
          hints.enqueue(i);
          hints.enqueue(j);
          sudoku=LogicRules(sudoku,hints);
          
        }
      }
    }
    
    return sudoku;
  }
  
  //This method applies the concept of generalization
  public static Cell[][] Generalization (Cell[][] sudoku, Queue<Integer> hints){
    
    //Generalization for the rows
    for(int i=0;i<9;i++){
      int countRow=0;
      int row=0;
      int column=0;
      for(int k=1;k<10;k++){
        for(int j=0;j<9;j++){
          if (sudoku[i][j].containsValue(k)){
            countRow++;
            row=i;
            column=j;
          }
        }
        if(countRow==1){
          if(sudoku[row][column].getValue()==0){
            sudoku[row][column].setValue(k);
            for (int h=1;h<=9;h++){
              if (h!=k){
                sudoku[row][column].removePossibleValue(h);
              }
            }
            hints.enqueue(row);
            hints.enqueue(column);
            break;
          }
        }
        
      }
    }
    
    //Generalization for the columns
    for(int j=0;j<9;j++){
      int countColumn=0;
      int row=0;
      int column=0;
      for(int k=1;k<10;k++){
        for(int i=0;i<9;i++){
          if (sudoku[i][j].containsValue(k)){
            countColumn++;
            row=i;
            column=j;
          }
        }
        if(countColumn==1){
          if(sudoku[row][column].getValue()==0){
            sudoku[row][column].setValue(k);
            for (int h=1;h<=9;h++){
              if (h!=k){
                sudoku[row][column].removePossibleValue(h);
              }
            }
            hints.enqueue(row);
            hints.enqueue(column);
            break;
          }
        }
      }
    }
    
    
    //Generalization for the blocks
    for(int k=1;k<10;k++){
      for (int g=1;g<10;g++){
        int countBlock=0;
        int row=0;
        int column=0;
        for(int i=0;i<9;i++){
          for(int j=0;j<9;j++){
            if (sudoku[i][j].getBlockNumber()==k){
              if (sudoku[i][j].containsValue(g)){
                countBlock++;
                row=i;
                column=j;
              }
            }
          }
        }
        
        if(countBlock==1){
          if(sudoku[row][column].getValue()==0){
            sudoku[row][column].setValue(g);
            for (int h=1;h<=9;h++){
              if (h!=g){
                sudoku[row][column].removePossibleValue(h);
              }
            }
            hints.enqueue(row);
            hints.enqueue(column);
            break;
          }
        }
        
      }
    }
    return sudoku;

  }
  //Method to determine whether the sudoku is solved
  public static boolean Solved (Cell[][]sudoku){
    
    for(int i=0;i<9;i++){
      for(int j=0;j<9;j++){
        if(sudoku[i][j].getValue()==0){
          return false;
        }
      }
    }
    return true;
  }
  
  //Method to copy
  public static Cell[][] Copy(Cell[][] sudoku, Cell[][] copy){
    for (int i=0;i<9;i++){
      for (int j=0;j<9;j++){
        copy[i][j]=sudoku[i][j];
      }
    }
    return copy;
  }
  
  //This method applies the principles of logic rules, generalization and branching to solve any sudoku
  public static Cell[][] Enumeration(Cell[][] sudoku, Queue<Integer> hints, Cell[][]copy){
    
    sudoku=LogicRules(sudoku,hints); 
    sudoku=Generalization(sudoku,hints);
    
    while((!hints.isEmpty())){ 
      sudoku=LogicRules(sudoku,hints); 
      sudoku=Generalization(sudoku,hints);
    }
    
    if (Solved(sudoku)==true){
      return sudoku;
    }
    else{
    
      
//To make it simpler, we enumerate a cell which has the least amount of possible values
      
      int minx=10;
      int x=0;
      int row=0;
      int column=0;
      int guess=0;
      
      for (int i=0;i<9;i++){
        for (int j=0;j<9;j++){
          if (sudoku[i][j].getValue()==0){
            x =sudoku[i][j].numberOfCandidates();
            if(x<minx){
              minx=x;
              row= i;
              column= j; 
            }
          }
        }
      }
      
      
      int numberOfGuesses=0;
      
      //Applies the logic of branching
      while(numberOfGuesses < sudoku[row][column].numberOfCandidates()){
        copy=Copy(sudoku,copy);
        
        //Change the cell of the guess to its value
        guess=copy[row][column].getPossibleValue(numberOfGuesses);
        copy[row][column].setValue(guess);
        for(int i=1;i<10;i++){
          if(i!=guess){
            copy[row][column].removePossibleValue(i);
          }
        }
        
       
        hints.enqueue(row);
        hints.enqueue(column);
        
        //This method prints out the guesses in-between in order to understand the process of branching better and check for errors.
        System.out.println(row+ "number  " + column + "number.");
        for (int i=0; i<9 ; i++){
          for (int j=0; j<9 ; j++){
            System.out.print(copy[i][j].getValue() + " ");
          }
          System.out.println();
        }
        System.out.println();
 
        
        //Search for contradiction
        boolean contradiction=false;
        for(int i=0;i<9;i++){
          for(int j=0;j<9;j++){
            if (copy[i][j].numberOfCandidates()==0){
              contradiction=true;
            }
          }
        }
        
        for(int i=0;i<9;i++){
          int countRow=0;
          for(int k=1;k<10;k++){
            for(int j=0;j<9;j++){
              if (copy[i][j].containsValue(k)){
                countRow++;
              }
            }
            if (countRow==0){
              contradiction=true;
            }
          }
        }
        
        for(int j=0;j<9;j++){
          int countColumn=0;
          for(int k=1;k<10;k++){
            for(int i=0;i<9;i++){
              if (copy[i][j].containsValue(k)){
                countColumn++;
              }
            }
            if (countColumn==0){
              contradiction=true;
            }
          }
        }
        
        for(int k=1;k<10;k++){
          for (int g=1;g<10;g++){
            int countBlock=0;
            for(int i=0;i<9;i++){
              for(int j=0;j<9;j++){
                if (copy[i][j].getBlockNumber()==k){
                  if (copy[i][j].containsValue(g)){
                    countBlock++;
                  }
                }
              }
            }
            if (countBlock==0){
              contradiction=true;
            }
          }
        }
        if(contradiction==false){
          
          if (Solved(copy)==true){
            return copy;
          }
          else{
            for(int i=0;i<0;i++){
              for(int j=0;j<9;j++){
                if (copy[i][j].numberOfCandidates()==0){
                  while(!hints.isEmpty()){
                    hints.dequeue();
                    numberOfGuesses++;}
                }
              }
            }
            copy=Enumeration(copy,hints,copy);
          }
        }

      return sudoku;
    }
  }
    return sudoku;
}
}





